<template>
  <div class="ordering">
    数据分析
  </div>
</template>

<script>
 
</script>

<style scoped="scoped">
  @import '../../../style/pubiss.css';
</style>
