<template>
  <div class="ordering">
    评价管理
  </div>
</template>

<script>
 
</script>

<style scoped="scoped">
  @import '../../../style/pubiss.css';
</style>
