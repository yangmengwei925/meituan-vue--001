module.exports = {
	mburl:'你的阿里云数据库链接'
}