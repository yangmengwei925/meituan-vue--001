<template>
	<view class="prefer-title">
			附近商家
	</view>
</template>

<script>
</script>

<style scoped>
	.prefer-title{font-size: 35upx;  height: 50upx; line-height: 50upx;
		margin-bottom: 20upx;}
</style>
